/*
 * 		FONCTIONS DE CALCUL :
 * 	ADDITION DE TUILES, SCORE, AIDE...
 * 
 */ 
#include "4096.h"

void initalise_plateau(int *nombreZeros);

/* FONCTION "HUB" POUR TOUS LES DEPLACEMENTS */
BOOL deplacer_vers(choixBouton boutonChoisi, modeFusion fusion, int *nbZeros, int *score);

/* FONCTIONS DE DEPLACEMENT EN MODE FUSION CLASSIQUE */
BOOL fusion_classique_bas(int *nombreZeros, int *score, BOOL doitJouer);
BOOL fusion_classique_haut(int *nombreZeros, int *score, BOOL doitJouer);
BOOL fusion_classique_droite(int *nombreZeros, int *score, BOOL doitJouer);
BOOL fusion_classique_gauche(int *nombreZeros, int *score, BOOL doitJouer);

/* FONCTION DE CALCUL POUR L'AIDE */
choixBouton meilleur_coup();

/* FONCTIONS DE GENERATION DE NOUVELLES TUILES */
void generer_nouvelle_tuile(modeDifficulte difficulte, int* nbZeros);
void generer_nouvelle_tuile_facile(int* nbZeros);
void generer_nouvelle_tuile_difficile(int* nbZeros);

/* FONCTIONS DE FIN DE PARTIE */
BOOL a_gagne();
BOOL a_perdu();
