#include "4096.h"
#include "affichage.h"
#include "calculs.h"
#include "controle.h"

//compilations : ....:....:....:....:....:....:....:....:....:....|....:....:....:....:....:....:....:....:....:....|
//               ....:....:....:....:....:....:....:....:....:....|....:....:....:....:....:....:....:....:....:....|
//				 ....:....:....:....:....:....:....:....:....:....|....:....:....:....:....:....:....:....:....:....|
//				 ....:....:....:....:....:....:....:....:....:....|....:....:....:.

int main()
{
	init_graphics(L_FENETRE,H_FENETRE);
	affiche_auto_off();

	int score=0, nbZeros=T_GRILLE*T_GRILLE;
	BOOL aideActivee=False, start=False, finDePartie=False;
	choixBouton boutonChoisi, boutonPropose;
	modeDifficulte difficulte = FACILE;
	modeAffichage affichage = AFF0;
	modeFusion fusion = CLASSIQUE;
	
	/* Ecran d'accueil avec réglage des paramètres */
	affiche_accueil(difficulte, affichage, fusion);
	do
	{	
		boutonChoisi=attendre_parametres(); //fonction bloquante attendant un clic sur un bouton
		if(boutonChoisi==START) start=TRUE;
		else changer_parametres(boutonChoisi, &difficulte, &affichage, &fusion);
		affiche_accueil(difficulte, affichage, fusion);
	}while(!start);
	
	/* Ecran de jeu */
	initalise_plateau(&nbZeros);
	affiche_jeu();
	affiche_score(score);
	affiche_plateau(affichage);

	do //while(!finDePartie)
	{
		if(aideActivee)
		{
			score--;
			boutonPropose=meilleur_coup();
			affiche_bouton_propose(boutonPropose);
		}
		boutonChoisi=attendre_selection(); //fonction bloquante attendant un clic sur un bouton
		if(boutonChoisi==AIDE)
		{
			aideActivee=!aideActivee;
			affiche_bouton_Aide(aideActivee);
		}
		else if(boutonChoisi==QUITTER) finDePartie=True;
		else
		{
			if(deplacer_vers(boutonChoisi, fusion, &nbZeros, &score)) //double opération : déplacement dans le sens choisi ET si le plateau a effectivement changé...
				generer_nouvelle_tuile(difficulte, &nbZeros);		  //...alors on génère une nouvelle tuile
		}
		affiche_score(score);
		affiche_plateau(affichage);
		efface_bouton_propose(); //efface l'aide éventuellement proposée, pour le prochain coup
		if(a_gagne())
		{
			affiche_gagne();
			finDePartie=True;
			wait_clic();
		}
		else if(a_perdu(&nbZeros))
		{
			affiche_perdu();
			finDePartie=True;
			wait_clic();
		}
	}while(!finDePartie);
	
	
	return 0 ;
}
